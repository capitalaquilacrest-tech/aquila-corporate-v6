AQUILA CREST LANDING PAGE — VNEXT PRODUCTION-ALIGNED EDITION

IMPORTANT DESIGN DECISION
This version improves the public website only. It does not change the existing Aquila member system, earning records, payout logic, Capital Reserve rules, approval workflows, or familiar Member Portal interface.

CONNECTED LINKS
Member Portal: https://script.google.com/macros/s/AKfycbwsX7fvxdza7pGepFtME77y0BK3D6AzQ8qIQMQOe51RfPk2rK-sCCbexo8PpdC2cpRG/exec
Official Website: https://www.aquilacrestcapital.com
Telegram: https://t.me/aquilacrestcapital
Facebook Group Chat: https://m.me/j/AbYdk_yzq3OXYb5o/?send_source=gc%3Acopy_invite_link_t
Discord: https://discord.gg/9JHYkPZkXS
Email: capitalaquilacrest@gmail.com

INCLUDED
- All Member Portal / Login / Create Account buttons connected to the current Apps Script web app
- Official community links
- Stronger About Aquila section aligned with the existing system
- Privacy Policy
- Terms of Use
- Disclaimer
- PWA manifest, install prompt support, service worker, and app icons
- Canonical URL, SEO description, Open Graph metadata and social sharing cover
- Production footer and security reminder
- V3 visual experience retained

DEPLOYMENT
Upload the complete contents of the aquila_landing_vnext folder to your hosting provider. Do not upload only index.html because the policy pages, assets, PWA files, and icons are also required.

LEGAL NOTE
The included policy documents are tailored operational templates, not a substitute for review by a Philippine lawyer or data protection professional.
